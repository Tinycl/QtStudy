#ifndef TEACHER_H
#define TEACHER_H

#include <QObject>

class Teacher : public QObject
{
    Q_OBJECT
public:
    explicit Teacher(QObject *parent = nullptr);

signals:
    //信号返回值为void，只需声明。需要有Q_PBJECT宏。
    void hungery();
    void hungery(QString foodName);

public slots:

};

#endif // TEACHER_H
