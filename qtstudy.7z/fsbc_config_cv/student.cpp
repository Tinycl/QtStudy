#include "student.h"
#include <QDebug>
Student::Student(QObject *parent) : QObject(parent)
{

}

void Student::treat()
{
    qDebug()<<"student treat teacher";
}

void Student::treat(QString foodName)
{
    //QString -> QByteArray (.toUtf8()) -> char* (.data())
    qDebug()<<"student treat teacher "<<foodName.toUtf8().data();
}
