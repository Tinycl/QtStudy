#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>
#include <QPushButton>
#include <QMenuBar>
#include <QMenu>
#include <QToolBar>
#include <QStatusBar>
#include <QLabel>
#include <QDockWidget>
#include <QTextEdit>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{

    ui->setupUi(this);

    resize(1000,800);
    //setFixedSize(800,600);
    setWindowTitle("fsbc config for cv");

    //菜单栏最多有一个
    //创建菜单栏
    QMenuBar *bar1 =  menuBar();
    setMenuBar(bar1);
    //创建菜单
    QMenu *fileMenu = bar1->addMenu("file");
    QMenu *viewMenu = bar1->addMenu("view");
    //创建菜单项
    QAction *newAction = fileMenu->addAction("new");
    //添加分割线
    fileMenu->addSeparator();
    QAction *openAction = fileMenu->addAction("open");


    //工具栏可以有多个
    QToolBar *toolBar = new QToolBar(this);
    addToolBar(Qt::LeftToolBarArea,toolBar);
    //toolBar->setAllowedAreas(Qt::LeftToolBarArea|Qt::RightToolBarArea);
    toolBar->addAction(newAction);
    toolBar->addAction(openAction);
    //再工具栏中添加控件
    QPushButton *btn3 = new QPushButton("aa", this);
    toolBar->addWidget(btn3);

    //状态栏，只能有一个
    QStatusBar *statuBar = new QStatusBar();
    setStatusBar(statuBar);
    QLabel *label = new QLabel("status left",this);
    statuBar->addWidget(label);
    QLabel *label1 = new QLabel("status right",this);
    statuBar->addPermanentWidget(label1);

    //浮动窗口
    QDockWidget *dockWidget = new QDockWidget("dock",this);
    addDockWidget(Qt::BottomDockWidgetArea,dockWidget);

    //编辑窗口
    QTextEdit *edit = new QTextEdit(this);
    edit->resize(100,100);
    edit->move(400,200);
    //setCentralWidget(edit);


    QPushButton *btn = new QPushButton;
    btn->setParent(this);
    btn->setText("next");
    btn->move(150,50);
    btn->resize(50,50);
    connect(btn,&QPushButton::clicked, this, &MainWindow::close);

    m_stu = new Student(this);
    m_tea = new Teacher(this);

    //声明信号，声明和实现槽函数
    //建立信号和槽函数的连接
    //触发信号
    //connect(m_tea, &Teacher::hungery, m_stu, &Student::treat);
    //teacherEmitSignal();

    //信号重载, 需要通过函数指针区分哪一个信号和哪一个槽函数
//    void (Teacher::*teaSignal)() = &Teacher::hungery;
//    void (Student::*stuSlot)() = &Student::treat;
//    connect(m_tea, teaSignal, m_stu, stuSlot);
//    teacherEmitSignal();

    void (Teacher::*teaSignal)(QString) = &Teacher::hungery;
    void (Student::*stuSlot)(QString) = &Student::treat;
    connect(m_tea, teaSignal, m_stu, stuSlot);
    teacherEmitSignal("rice");



    QPushButton *btn2 = new QPushButton;
    btn2->setParent(this);
    btn2->move(250,50);
    btn2->resize(50,50);
    btn2->setText("下课");
    void (Teacher::*teaSignal1)() = &Teacher::hungery;
    void (Student::*stuSlot1)() = &Student::treat;
    //信号连接信号，信号触发信号
    connect(m_tea, teaSignal1, m_stu, stuSlot1);
    connect(btn2, &QPushButton::clicked, m_tea, teaSignal1); //clicked参数是bool，后面槽函数的参数要注意了

    //断开信号
    //disconnect(m_tea, teaSignal1, m_stu, stuSlot1);

    //一个信号可以连接多个槽函数
    //多个信号可以连接一个槽函数
    //信号和槽函数参数类型必须一致， 信号参数个数大于等于槽函数参数的个数




}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::teacherEmitSignal()
{

    emit m_tea->hungery();
}

void MainWindow::teacherEmitSignal(QString str)
{
    emit m_tea->hungery(str);
}
