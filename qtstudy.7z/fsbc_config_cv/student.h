#ifndef STUDENT_H
#define STUDENT_H

#include <QObject>

class Student : public QObject
{
    Q_OBJECT
public:
    explicit Student(QObject *parent = nullptr);

signals:

public slots:
    //槽函数返回值为void， 需要实现
    void treat();
    void treat(QString foodName);

};

#endif // STUDENT_H
