#include "globalvar.h"

unsigned int g_a = 0;
