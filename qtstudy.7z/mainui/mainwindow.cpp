#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPushButton>
#include <QDialog>
#include <QDebug>
#include <QMessageBox>
#include <QTextEdit>
#include <QRadioButton>
#include <QButtonGroup>
#include <QListWidgetItem>
#include <QString>
#include <QTreeWidgetItem>



MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    //ui->pushButton->
    connect(ui->actionnew, &QAction::triggered, [=](){
       //模态对话框，阻塞
       QDialog dlg(this);
       dlg.resize(200,200);
       dlg.exec();
       //非模态对话框， 非阻塞
       QDialog *dlg1 = new QDialog(this);
       dlg1->resize(200,100);
       dlg1->setAttribute(Qt::WA_DeleteOnClose);
       dlg1->show();

       //标准对话框
       QMessageBox::critical(this,"critical","错误");

       //QString str;
       //str = ui->textEdit->toPlainText();
      // qDebug()<<str;


    });

    connect(ui->radioButton, &QRadioButton::clicked, [&](){
        g_a = g_a + 1;
        qDebug()<<g_a;
    });

    QButtonGroup *rdbtns = new QButtonGroup(this);
    rdbtns->addButton(ui->radioButton,0);
    rdbtns->addButton(ui->radioButton_2,1);
    ui->radioButton->setChecked(true);

    ui->checkBox->setCheckState(Qt::Checked);

    QListWidgetItem *listItem = new QListWidgetItem("list");
    ui->listWidget->addItem(listItem);

    QStringList liststr;
    liststr<<"aa"<<"bb"<<"cc";
    ui->listWidget->addItems(liststr);

    ui->treeWidget->setHeaderLabels(QStringList()<<"name"<<"sex");
    QTreeWidgetItem *item = new QTreeWidgetItem(QStringList()<<"xiaoming");
    ui->treeWidget->addTopLevelItem(item);
    QTreeWidgetItem *item_l = new QTreeWidgetItem(QStringList()<<"man");
    item->addChild(item_l);

    ui->tableWidget->setColumnCount(3);
    ui->tableWidget->setHorizontalHeaderLabels(QStringList()<<"name"<<"sex"<<"age");
    ui->tableWidget->setRowCount(1);
    ui->tableWidget->setItem(0,0,new QTableWidgetItem("xiao ming"));
    ui->tableWidget->setItem(0,1,new QTableWidgetItem("man"));
    ui->tableWidget->setItem(0,2,new QTableWidgetItem("18"));



    connect(ui->pushButton, &QPushButton::clicked, [=](){
        qDebug()<<g_a;

        int option = 0;
        option = rdbtns->checkedId();
        switch(option)
        {
            case 0:
            {
                qDebug()<<"option 0";
                break;
            }
            case 1:
            {
                qDebug()<<"option 1";
                break;
            }
            default:   break;

        }

        if(Qt::Checked == ui->checkBox->checkState())
        {
            qDebug()<<"check box is checked";
        }
    });

        m_chwind1 = new ChildWindow1(this);
        connect(ui->pushButton_2, &QPushButton::clicked, [=](){
            m_chwind1->show();
        });
}

MainWindow::~MainWindow()
{
    delete ui;
}

