#ifndef GLOBALVAR_H
#define GLOBALVAR_H

extern unsigned int g_a;
#endif // GLOBALVAR_H
