#include "childwindow1.h"
#include "ui_childwindow1.h"

ChildWindow1::ChildWindow1(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::ChildWindow1)
{
    ui->setupUi(this);
}

ChildWindow1::~ChildWindow1()
{
    delete ui;
}
