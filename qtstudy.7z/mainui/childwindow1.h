#ifndef CHILDWINDOW1_H
#define CHILDWINDOW1_H

#include <QMainWindow>


namespace Ui {
class ChildWindow1;
}

class ChildWindow1 : public QMainWindow
{
    Q_OBJECT

public:
    explicit ChildWindow1(QWidget *parent = nullptr);
    ~ChildWindow1();

private:
    Ui::ChildWindow1 *ui;
};

#endif // CHILDWINDOW1_H
